/**
 * 
 */
var myapp=angular.module("ServiceApp",[]);


myapp.controller("ServletController", function($scope,$http) {
	//Check your Server Port Number 
	$http.get('http://localhost:9090/Lesson04-Http/Contact.json').
	success(function(data) {
		$scope.contact=data.contacts;//from Contact JSON
	});
})